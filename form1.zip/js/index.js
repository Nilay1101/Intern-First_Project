$(document).ready(function() {  
  $('.multiselect').multiselect();
  $('.datepicker').datepicker();  
});