<html>
    <head>
        <title>Sportz.com</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=yes">
        <?php include 'includeheader.php'; ?>
        <link href="css/theme.css" rel="stylesheet">
        <link href="css/jquery-ui.css" rel="stylesheet">
        <link href="js/select2/select2.css" rel="stylesheet">
        <link media="handheld, only screen and (max-width: 480px), only screen and (max-device-width: 480px)" href="css/mobile_index.css" type="text/css" rel="stylesheet" />
        <link media="handheld, only screen and (max-width: 480px), only screen and (max-device-width: 480px)" href="css/mobile_header.css" type="text/css" rel="stylesheet" />
        <script src="js/select2/select2.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <script>
            $(function() {
                $('.select_games').select2({
                    maximumSelectionSize: 3,
                    placeholder:"Select game"
                });
                $(".links a").hover(function(e){
                    e.preventDefault();
                    $(this).tab('show');
                });
                
                //var type = $('#type_type').val();
                /*$('#type_type').change(function(){
                    var type = $('#type_type').val();
                    $("#sports_type").autocomplete({
                        source: 'search_bar.php?key='+type,
                        minLength:0,
                    });
                });*/
                    
                    
                
                    $("#area").autocomplete({
                        source:"search_bar.php",
                        minLength:0,
                    });
                
            
         });
        </script>
            
    </head>
    <body>
        <header class="header" >
        <?php include 'header.php';?>
        <?php //include 'breadcrumb.php';?>    
        </header>
        
        <div>
            
            <div class="jumbotron">
                <h2 class="text-center">
                    Welcome to Sportz.com..<br>
                    Here you can search different Academy, Coach, Tournament<br>
                    
                </h2>
                
                <form action="result.php" method="POST">
                    
                    <div class="form-group form-inline text-center has-feedback" style="margin-top: 15px;">
                        
                        
                        <div class="input-group">
                                <!--<input input="text" id="sports_type" name="sports_type" class="form-control" style="//margin-top: 15px; width: 180px;" placeholder="Sports Type...">-->
                            <?php include 'includeselectlist.php';?>
                            <span class="input-group-addon"><span class=" glyphicon glyphicon-chevron-down"></span></span>
                        </div>
                        
                        <div class="input-group">
                                <input id="area" class="form-control search_input" name="query" style="" placeholder="Search any Academy/Tournament/Venue/Coach..." >
                        </div>
                        
                            
                        <button type="submit" class="btn" style="">Search</button>
                    </div><br><br>
                </form>
            </div>
        </div>
        <div class="row star-box">
            <div class="col-sm-1" ></div>
            <div class="col-sm-4 pull-left">
                <div class="" id="">
                    <ul class="nav links">
                        <li class="active first-link"><a data-toggle="tab" href="#content_for_id1"><p style="margin-left:-7px;">Academy</p></a></li>
                        <li><a data-toggle="tab" href="#content_for_id2">Coaches</a></li>
                        <li><a data-toggle="tab" href="#content_for_id3"><p style="margin-top:-10px;">Clubs & Teams</p></a></li>
                        <li><a data-toggle="tab" href="#content_for_id4" style="background:green url('images/pattern.png') top repeat ; color:yellow;">Sportz</a></li>
                        <li><a data-toggle="tab" href="#content_for_id5">Players</a></li><br/><br/><br/><br/><br/><br/>
                        <li class="first-link"><a data-toggle="tab" href="#content_for_id6" style="">Venues</a></li>
                        <li><a data-toggle="tab" href="#content_for_id7"><p style="margin-left:-20px;">Tournament</p></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-5 tab-content content-box">
                <div class="tab-pane fade in active" id='content_for_id1'>
                    <div class="jumbotron1 text-center">
                        <h3>Academy</h3>
                    </div>
                </div>
                <div class="tab-pane fade" id='content_for_id2'>
                    <div class="jumbotron1 text-center">
                        <h3>Coaches</h3>
                    </div>
                </div>
                <div class="tab-pane fade" id='content_for_id3'>
                    <div class="jumbotron1 text-center">
                        <h3>Clubs & Teams</h3>
                    </div>
                </div>
                <div class="tab-pane fade" id='content_for_id4'>
                    <div class="jumbotron1 text-center">
                        <h3>TheSportx.com</h3>
                    </div>
                </div>
                <div class="tab-pane fade" id='content_for_id5'>
                    <div class="jumbotron1 text-center">
                        <h3>Players</h3>
                    </div>
                </div>
                <div class="tab-pane fade" id='content_for_id6'>
                    <div class="jumbotron1 text-center">
                        <h3>Venues</h3>
                    </div>
                </div>
                <div class="tab-pane fade" id='content_for_id7'>
                    <div class="jumbotron1 text-center">
                        <h3 style="margin-top: -5px;">Upcoming Tournaments</h3>
                        <div class="table-responsive">
                        <table class="table" >
                            <thead style="font-size: 95%;">
                            <th class="text-center">Tournaments Cricket &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                <th>Registration End-date</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><a href="#"> Sundar Raja T20 cup vikhroli</a></td>
                                    <td>June 4,2015</td>
                                </tr>
                                <tr>
                                    <td><a href="#">tournament 2</a></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td><a href="#">tournament 3</a></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td><a href="#">tournament 4</a></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td><a href="#">tournament 5</a></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td><a href="#">tournament 6</a></td>
                                    <td></td>
                                </tr>

                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
        <br><br>
        <div class="col-xs-6"><div class="table-responsive">
            <table class="table table-hover" >
                <caption class="text-center capt">Upcoming</caption>
                <thead>
                    <th>Tournament - cricket sort</th>
                    <th>Registration end date sort</th>
                    <th>Tournament days-sort</th>
                </thead>
                <tbody>
                    <tr>
                        <td><a href="#"> Sundar Raja T20 cup vikhroli</a></td>
                        <td>June 4,2015</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 2</a></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 3</a></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 4</a></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 5</a></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 6</a></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 7</a></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 8</a></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            More...
            </div>
        </div>
        
        <div class="col-xs-6"><div class="table-responsive ">
            <table class="table table-hover ">
                <caption class="text-center capt">Ended</caption>
                <thead >
                <th class="text-center">Tournament - cricket sort</th>
                <th class="text-center">Winner</th>
                </thead>
                <tbody>
                    <tr>
                        <td><a href="#">Sundar Raja T20 cup Andheri</a></td>
                        <td>Suman XI</td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 2</a></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 3</a></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 4</a></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 5</a></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 6</a></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 7</a></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><a href="#">tournament 8</a></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>More...
            </div>
        </div>
        <br>
        
        <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="0">
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active">1</li>
                <li data-target="#myCarousel" data-slide-to="1">2</li>
                <li data-target="#myCarousel" data-slide-to="2">3</li>
                <li data-target="#myCarousel" data-slide-to="3">4</li>
            </ol>
            
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <img src="images/img1.jpg">
                </div>
                <div class="item">
                    <img src="images/img2.jpg" >
                </div>
                <div class="item">
                    <img src="images/img3.jpg" >
                </div>
                <div class="item">
                    <img src="images/img4.jpg" >
                </div>
                 
            </div>
            
            <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                
                
                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                
                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true">
                </span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <br>
        <br>
        
        <div class="row">
            <div class="col-sm-12">
                <div class="row">
                    <div class="col-md-3">
                        <div class="box text-center">
                            <h4>Top Coaches in Mumbai</h4>
                            <h5><a href="#">XYZ person,Bandra</a></h5>
                            <h5><a href="#">DEF person,Kurla</a></h5>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="box text-center">
                            <h4>Top Tournaments in Mumbai</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="box text-center">
                            <h4>Top Academy in Mumbai</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="box text-center">
                            <h4>Top Coaches in Mumbai</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        
        <?php //include 'share.php';?>
        <?php include 'footer.php';?>
    </body>
</html>
