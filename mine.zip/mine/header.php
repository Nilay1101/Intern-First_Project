<html><style>
.navbar-nav > li > a {padding-top:5px !important; padding-bottom:5px !important;}
.navbar {min-height:32px !important}
</style>
<nav class="navbar navbar-default navbar-static-top" >
    <div class="navbar-header col-md-3">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php"><img src="images/S6.png"></a>
    </div>
    <div class="collapse navbar-collapse col-md-9 pull-right" id="example-navbar-collapse">
        <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Mumbai<b class="caret"></b></a>
                <ul class="dropdown-menu inside-li">
				<li class="active"><a href="#">1. Mumbai</a></li>
				    <li><a href="#">2. Hyderabad</a></li>
                    <li><a href="#">3. Pune</a></li>
					<li><a href="#">4. Bangalore</a></li>
                    <li><a href="#">5. Chennai</a></li>
                    <li><a href="#">6. Delhi</a></li>
                    <li><a href="#">7. Kolkata</a></li>
                    
                </ul>
            </li>
            <li><a href="#">Academy</a></li>
            <li><a href="#">Tournament</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Login / Signup</a></li>
        </ul>
    </div>
</nav>
</html>


