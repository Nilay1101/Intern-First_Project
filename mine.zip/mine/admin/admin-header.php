<nav class="navbar navbar-default navbar-fixed-top" role="navigation" data-spy="affix" data-offset-top="40">
    <div class="navbar-header col-md-3">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php"><img src="../images/S6.png"></a>
    </div>
    <div class="collapse navbar-collapse col-md-9 pull-right" id="example-navbar-collapse">
        <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">City <b class="caret"></b></a>
                <ul class="dropdown-menu inside-li">
                    <li><a href="#">Pune</a></li>
                    <li><a href="#">Chennai</a></li>
                    <li><a href="#">Banglore</a></li>
                    <li><a href="#">Delhi</a></li>
                    <li><a href="#">Mumbai</a></li>
                </ul>
            </li>
            <li><a href="#">Academy</a></li>
            <li><a href="#">Tournament</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Login / Signup</a></li>
        </ul>
    </div>
</nav>
