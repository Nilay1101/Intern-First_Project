
<div class="box">
    <hr>
    <p class="btn btn-success pull-right">4.3</p>
        <address>
            <div class="name"><a href="#"><?php echo $row['name_academy'];?></a></div>
            <strong>Address ></strong><?php echo $row['address'];?>
            <br><strong>Timings ></strong><?php echo $row['timings'];?>
            <br><strong>Fess ></strong><?php echo $row['fees'];?>
            <br><strong>No of Coaches > </strong><?php echo $row['coaches'];?>
        <br>
            <ol class="list-inline pull-right box-list">
                <li><img src="images/tick1.png"></li>
                <li><img src="images/tick1.png"></li>
                <li><img src="images/tick1.png"></li>
                <li><img src="images/tick1.png"></li>
                <li><img src="images/tick1.png"></li>
            </ol>
        </address>
</div><br>
