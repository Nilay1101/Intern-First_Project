<select style="height:45px; width:200px" name="selected_games[]" class="select_games" multiple="multiple" maximumSelectionLength="2" style="">
    <option selected="selected">Cricket</option>
    <option>Swimming</option>
    <option>Aqua</option>
    <option>Football</option>
    <option>Tennis</option>
    <option>Gym</option>
    <option>Training</option>
    <option>Kabaddi</option>
    <option>Athletics</option>
    <option>Badminton</option>
    <option>Basketball</option>
    <option>Carrom</option>
    <option>Chess</option>
    <option>Table Tennis</option>
    <option>Vollyball</option>
    <option>Boxing</option>
    <option>Wrestling</option>
    <option>Hockey</option>
    <option>Billiards</option>
    <option>Snooker</option>
    <option>Archery</option>
    <option>Golf</option>
    <option>Cycling</option>
    <option>Traditional Sports</option>
</select>