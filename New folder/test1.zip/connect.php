
<?php
/*It contains database connection informantion 
which can be changed and result is reflected to all pages*/
		ob_start();
		$conn=mysql_connect('farmtocustomer.com.mysql','farmtocustomer_','Tvv8yYjd');//
		mysql_select_db('farmtocustomer_');
?>
