<?php 


session_start();
$_SESSION['feessort']=1;
echo $_SESSION['feessort'];
 

?>