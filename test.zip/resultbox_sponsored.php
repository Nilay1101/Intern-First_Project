<div class="sponsored-box">
    <hr>
    <div class="thumbnail">
        <div class="caption">
            <center><h3><a class="label label-success" href="#">XYZ Academy</a></h3></center>
        </div>
        <img src="images/img1.jpg" class="img-responsive img-rounded">
    </div>
</div>