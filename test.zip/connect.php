<?php
$dbhost = 'farmtocustomer.com.mysql';
$dbuser = 'farmtocustomer_';
$dbpass = 'Tvv8yYjd';
$db = 'farmtocustomer_';
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}
mysql_select_db($db);
?>
