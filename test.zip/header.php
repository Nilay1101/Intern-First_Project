<nav class="navbar navbar-default navbar-fixed-top" role="navigation" data-spy="affix" data-offset-top="40">
    <div class="navbar-header col-md-3">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php"><img src="images/S6.png"></a>
    </div>
    <div class="collapse navbar-collapse col-md-9 pull-right" id="example-navbar-collapse">
        <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">City <b class="caret"></b></a>
                <ul class="dropdown-menu inside-li">
                    <li><a href="#">Pune</a></li>
                    <li><a href="#">Chennai</a></li>
                    <li><a href="#">Banglore</a></li>
                    <li><a href="#">Delhi</a></li>
                    <li><a href="#">Mumbai</a></li>
                </ul>
            </li>
            <li><a href="#">Academy</a></li>
            <li><a href="#">Tournament</a></li>
            <li><a href="#">About</a></li>
            
  
            <li class="text-center"><a href="#" role="button" data-toggle="modal" data-target="#login-modal">Login /Signup</a></li>



<!-- BEGIN # MODAL LOGIN -->
<div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header" align="center">
                <div class="col-lg-6 "><b><p> &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;Login to proceed</b></p></div>
                
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                    </button>
                    <hr>
                    <img class="img-circle" id="img_logo" src="images/S6.png">
                    
                </div>
                
                <!-- Begin # DIV Form -->
                <div id="div-forms">
                
                    <!-- Begin # Login Form -->
                    <form id="login-form">
                        <div class="modal-body">
                            <!--<div id="div-login-msg"> -->
<?php
// facebook
include_once("facebook_login_with_php/config.php");
include_once("facebook_login_with_php/includes/functions.php");
//destroy facebook session if user clicks reset
if(!$fbuser){
    $fbuser = null;
    $loginUrl = $facebook->getLoginUrl(array('redirect_uri'=>$homeurl,'scope'=>$fbPermissions));
    echo '<a href="'.$loginUrl.'" class="btn btn-block btn-social btn-facebook">
        <i class="fa fa-facebook"></i> Login with Facebook
      </a>';     
}else{
    $user_profile = $facebook->api('/me?fields=id,first_name,last_name,email,gender,locale');
    $user = new Users();
    $user_data = $user->checkUser('facebook',$user_profile['id'],$user_profile['first_name'],$user_profile['last_name'],$user_profile['email'],$user_profile['gender'],$user_profile['locale']);
    if(!empty($user_data)){
        // session_start();
        $_SESSION['userdata'] = $user_data;
        header("Location:account.php");
    }else{
        die('Some problem occurred, please try again.');
    }
}

//Googleplus
include_once("login-with-google-using-php/config.php");
include_once("login-with-google-using-php/includes/functions.php");
//print_r($_GET);die;
if(isset($_REQUEST['code'])){
    $gClient->authenticate();
    $_SESSION['token'] = $gClient->getAccessToken();
    header('Location: ' . filter_var($redirect_url, FILTER_SANITIZE_URL));
}
if (isset($_SESSION['token'])) {
    $gClient->setAccessToken($_SESSION['token']);
}
if ($gClient->getAccessToken()) {
    $userProfile = $google_oauthV2->userinfo->get();
    //DB Insert
    $gUser = new Users_google();
    $gUser->checkUser('google',$userProfile['id'],$userProfile['given_name'],$userProfile['family_name'],$userProfile['email'],$userProfile['gender'],$userProfile['locale'],$userProfile['link'],$userProfile['picture']);
    $_SESSION['google_data'] = $userProfile; // Storing Google User Data in Session
    header("location: login-with-google-using-php/account.php");
    $_SESSION['token'] = $gClient->getAccessToken();
} else {
    $authUrl = $gClient->createAuthUrl();
}
if(isset($authUrl)) {
    echo '<a href="'.$authUrl.'"class="btn btn-block btn-social btn-google-plus">
        <i class="fa fa-google-plus"></i> Login with Google
      </a>';     
} else {
    echo '<a href="login-with-google-using-php/logout.php?logout">Logout</a>';
}
?>
                               
                    <hr>
                  <div class ="row">By logging in, you agree to TheSPORTZ.COM

<a href="#"> Terms of Service, <a href="#">Cookie Policy, <a href="#"> Privacy Policy,

<a href="#">Content Policies.   
</div>   
                </div>
                <!-- End # DIV Form -->
                
            </div>
        </div>
    </div>
    <!-- END # MODAL LOGIN -->
        </ul>
    </div>
</nav>



