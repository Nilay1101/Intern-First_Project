<?php
include_once("facebook_login_with_php/inc/facebook.php"); //include facebook SDK
######### Facebook API Configuration ##########
$appId = '884067035022033'; //Facebook App ID
$appSecret = '7c22baceda456540de4329fe3b757bf2'; // Facebook App Secret
//$return_url = 'http://www.farmtocustomer.com/thesportz/test';  //return url (url to script)
$homeurl = 'http://www.farmtocustomer.com/thesportz/test';  //return to home
$fbPermissions = 'email';  //Required facebook permissions

//Call Facebook API
$facebook = new Facebook(array(
  'appId'  => $appId,
  'secret' => $appSecret

));
$fbuser = $facebook->getUser();
?>