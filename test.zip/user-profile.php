<html>
    <head>
        <title>Academy-Profile Sportz.com</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php include 'includeheader.php'; ?>
        <link href="css/user-profile.css" rel="stylesheet">
        <link media="handheld, only screen and (max-width: 480px), only screen and (max-device-width: 480px)" href="css/mobile_user-profile.css" type="text/css" rel="stylesheet" />
        <link media="handheld, only screen and (max-width: 480px), only screen and (max-device-width: 480px)" href="css/mobile_header.css" type="text/css" rel="stylesheet" />
            
    </head>

    <body>
        <header class="header">
        <?php include 'header.php';?>
        <?php //include 'breadcrumb.php';?>    
        </header>
        <ol class="breadcrumb" style="margin-top: 140px;margin-bottom: -130px;">
            <li>&nbsp;<a href="index.php" class="btn "><span class="glyphicon glyphicon-home"></span> Home</a></li><span class="glyphicon glyphicon-chevron-right"></span>
            <li><a href="result.php" class="btn ">Result</a></li><span class="glyphicon glyphicon-chevron-right"></span>
            <li><a href="academy-profile.php" class="btn ">Academy</a></li><span class="glyphicon glyphicon-chevron-right"></span>
            <li><a href="tournament.php" class="btn ">Tournament</a></li><span class="glyphicon glyphicon-chevron-right"></span>
            <li><a href="user-profile.php" class="btn current">User-Profile</a></li>
        </ol>
        <div class="start"></div>
        
        <div class="container-fluid">
           <div class="jumbotron profile-jumbo">
                <div class="row">
                    <div class="col-md-3">

                        <img src="images/avatar_2x.png " class="img-rounded">
                    </div>
                    <div class="col-md-9 info">
                        <div class="head">Name :</div><br>
                        <div class="head">Address :</div><br>
                        <div class="head">School/College :</div><br>
                        <div class="head">Clubs :</div><br>
                        <div class="head">Achievements :</div><br>
                        <div class="head">Contact :</div><br>
                    </div>
                </div>
            </div>
        </div>
        <br>
        
        <div class="container-fluid">
        <div class="row1">
        <div class="col-sm-4">
                <div class="row1">
                    <div class="col-sm-12">
                        <div class="jumbotron box_sports" >
                                 <div class="box_sports" style="margin-top:25px; margin-bottom:25px;">sports : multi select 
                        Type of player : depends on sports</div>
                    </div>         </div>
                    <div class="col-sm-12">
                    <div class="jumbotron box_teams">
                        <div class="box_teams" style="margin-top:25px; margin-bottom:25px;">
                            TEAMS/

                        IF NO TEAM CREATE TEAM SHOULD 

                        BE THERE
                        </div>  
                        </div>
                    </div>
                </div>
        </div>
        <div class="col-sm-4">
            <div class="row1">
                    <div class="col-sm-12">
                    <div class="jumbotron box_teams">
                        <div class="box_about">About me</div>
                    </div></div>
                    <div class="col-sm-12">
                     <div class="jumbotron box_teams">
                        <div class="box_images" style="margin-top:150px; margin-bottom:25px;"></div>
                    </div></div>
                </div>
        </div>
        <div class="col-sm-4">
            <div class="row1">
                    <div class="col-sm-12">
                     <div class="jumbotron box_upcoming">
                        <div class="box_upcoming "style="margin-top:150px; margin-bottom:25px;">
                            Upcoming events

                            based on his interests

                            can select the number of tourneys

                            and sponsored events ( related to 
    
                        him)        
                        </div></div>
                    </div>
                    <div class="col-sm-12">
                    <div class="jumbotron box_spons">
                        <div class="box_spons" style="margin-top:25px; margin-bottom:25px;">Sponsored clubs/ academies/

coaches</div></div>
                    </div>
                </div>
        </div>
    </div>   
     
        <br>
        </div>
        <?php include 'footer.php';?>
    </body>
</html>
