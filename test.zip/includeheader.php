<link href=' http://fonts.googleapis.com/css?family=Ubuntu:200,300,400' rel='stylesheet' type='text/css'>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-theme.min.css" rel="stylesheet">
<link href="css/header.css" rel="stylesheet">
<link href="css/bootstrap-social.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/modal.css">
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="modal.js"></script>
