<?php
//session_start();
include_once("login-with-google-using-php/src/Google_Client.php");
include_once("login-with-google-using-php/src/contrib/Google_Oauth2Service.php");
######### edit details ##########
$clientId = '328440181903-1v35dinpfiuqblpcdga213tibfv7ovjv.apps.googleusercontent.com'; //Google CLIENT ID
$clientSecret = '8IgcVKh-lcsapxDmnVtxB3jo'; //Google CLIENT SECRET
$redirectUrl = 'http://www.farmtocustomer.com/thesportz/test';  //return url (url to script)
$homeUrl = 'http://www.thesportz.com';  //return to home

##################################

$gClient = new Google_Client();
$gClient->setApplicationName('Login to codexworld.com');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);

$gClient->setRedirectUri($redirectUrl);

$google_oauthV2 = new Google_Oauth2Service($gClient);
?>